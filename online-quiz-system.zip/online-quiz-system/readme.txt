PROJECT: Online Quiz Platform - Major Project
TEAM: BALASAKTHI N, MANAV SALARIA, KOUSAR SHAIK, SAKTHI SUBHA, KRITHIK M S
GUIDE: Prof. Rupam Dey

INSTALLATION:
1. npm install
2. Create backend/.env file with:
   MONGO_URI=your_mongodb_atlas_uri
   JWT_SECRET=your_secret_key
   PORT=5001
3. node backend/create-admin.js (to create admin)
4. node backend/server.js
5. Open http://localhost:5001

ADMIN LOGIN:
Email: admin@quiz.com
Password: admin123 (set in create-admin.js)