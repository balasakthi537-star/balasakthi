# Online Quiz System - Fixed + Admin Dashboard

## Stack
- HTML5 / CSS3 / JavaScript
- Node.js / Express.js
- MongoDB Atlas / Mongoose
- JWT authentication
- bcryptjs

## Run
1. Open a terminal in `backend`.
2. Create `backend/.env` from `.env.example` and add your MongoDB URI and JWT secret.
3. Install dependencies: `npm install`
4. Create the admin account:
   `node create-admin.js "Quiz Admin" admin@example.com AdminPassword123`
5. Start the server:
   `npm run dev`
6. Open **http://localhost:5001/** in Chrome. Do not use VS Code Live Server/port 5500.

## Pages
- `/` - User login
- `/register.html` - Registration
- `/dashboard.html` - User dashboard
- `/quiz.html` - Quiz
- `/result.html` - Result
- `/leaderboard.html` - Leaderboard
- `/profile.html` - Profile
- `/admin-login.html` - Admin login
- `/admin-dashboard.html` - Admin dashboard

## Admin features
- Admin authentication
- Dashboard statistics
- Add/edit/delete categories
- Add/edit/delete questions
- View/delete quiz results
- View registered users

## MongoDB DNS note
The server sets Node DNS to `8.8.8.8` before connecting because some Cloudflare WARP DNS configurations can refuse MongoDB Atlas SRV queries.
