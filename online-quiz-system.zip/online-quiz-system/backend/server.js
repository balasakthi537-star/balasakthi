const dns = require("dns");
// Needed on systems where Cloudflare WARP DNS refuses MongoDB SRV queries.
dns.setServers(["8.8.8.8"]);

const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const path = require("path");
const cors = require("cors");

dotenv.config();

const authRoutes = require("./routes/auth");
const categoryRoutes = require("./routes/category");
const questionRoutes = require("./routes/question");
const quizRoutes = require("./routes/quiz");
const profileRoutes = require("./routes/profile");
const adminRoutes = require("./routes/admin");

const app = express();
const PORT = process.env.PORT || 5001;
const FRONTEND_PATH = path.join(__dirname, "..", "frontend", "public");

app.use(cors());
app.use(express.json());

// Serve the frontend from Express. Do not use VS Code Live Server for this project.
app.use(express.static(FRONTEND_PATH));

app.use("/api", authRoutes);
app.use("/api", categoryRoutes);
app.use("/api", questionRoutes);
app.use("/api", quizRoutes);
app.use("/api/profile", profileRoutes);
app.use("/api", adminRoutes);

app.get("/api/health", (req, res) => {
    res.json({
        status: "ok",
        database: mongoose.connection.readyState === 1 ? "connected" : "disconnected"
    });
});

// SPA/static fallback for existing HTML pages.
app.get("/", (req, res) => {
    res.sendFile(path.join(FRONTEND_PATH, "index.html"));
});

async function startServer() {
    if (!process.env.MONGO_URI) {
        console.error("MONGO_URI is missing in backend/.env");
        process.exit(1);
    }

    if (!process.env.JWT_SECRET) {
        console.error("JWT_SECRET is missing in backend/.env");
        process.exit(1);
    }

    try {
        await mongoose.connect(process.env.MONGO_URI, { family: 4 });
        console.log("MongoDB Connected");
        console.log("JWT_SECRET loaded: Yes");

        app.listen(PORT, () => {
            console.log(`Server running on http://localhost:${PORT}`);
            console.log(`Frontend: http://localhost:${PORT}/`);
            console.log(`Health:   http://localhost:${PORT}/api/health`);
        });
    } catch (error) {
        console.error("MongoDB connection error:", error.message);
        process.exit(1);
    }
}

startServer();
