const dns = require("dns");

// Fix MongoDB Atlas SRV DNS issue
dns.setServers(["8.8.8.8"]);

require("dotenv").config();

const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const User = require("./models/User");

async function createAdmin() {
    try {
        console.log("Connecting to MongoDB...");

        await mongoose.connect(process.env.MONGO_URI, {
            family: 4
        });

        console.log("MongoDB Connected");

        const name = process.argv[2] || "Admin";
        const email = process.argv[3] || "admin@example.com";
        const password = process.argv[4] || "AdminPassword123";

        const existingUser = await User.findOne({ email });

        if (existingUser) {
            console.log("A user with this email already exists.");

            if (existingUser.role !== "admin") {
                existingUser.role = "admin";
                await existingUser.save();

                console.log("Existing user promoted to admin.");
            } else {
                console.log("This user is already an admin.");
            }

            await mongoose.disconnect();
            return;
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const admin = new User({
            name,
            email,
            password: hashedPassword,
            role: "admin"
        });

        await admin.save();

        console.log("");
        console.log("=================================");
        console.log("Admin created successfully!");
        console.log("=================================");
        console.log("Name:", name);
        console.log("Email:", email);
        console.log("Role: admin");
        console.log("=================================");

        await mongoose.disconnect();

    } catch (error) {
        console.error("Could not create admin:", error.message);
        process.exit(1);
    }
}

createAdmin();