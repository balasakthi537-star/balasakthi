const express = require("express");
const Result = require("../models/Result");
const User = require("../models/User");
const Category = require("../models/Category");
const Question = require("../models/Question");
const auth = require("../middleware/auth");

const router = express.Router();

function adminOnly(req, res, next) {
    if (req.user?.role !== "admin") {
        return res.status(403).json({ message: "Admin access required" });
    }
    next();
}

router.use(auth, adminOnly);

// Admin dashboard statistics
router.get("/admin/stats", async (req, res) => {
    try {
        const [users, categories, questions, results] = await Promise.all([
            User.countDocuments({ role: "user" }),
            Category.countDocuments(),
            Question.countDocuments(),
            Result.countDocuments()
        ]);

        res.json({ users, categories, questions, results });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// View all quiz results
router.get("/admin/results", async (req, res) => {
    try {
        const results = await Result.find()
            .populate("userId", "name email")
            .populate("categoryId", "name")
            .sort({ date: -1 });

        res.json(results);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Delete a result
router.delete("/admin/results/:id", async (req, res) => {
    try {
        const deleted = await Result.findByIdAndDelete(req.params.id);

        if (!deleted) {
            return res.status(404).json({ message: "Result not found" });
        }

        res.json({ message: "Result deleted" });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// View users for the admin dashboard
router.get("/admin/users", async (req, res) => {
    try {
        const users = await User.find({ role: "user" })
            .select("name email role")
            .sort({ name: 1 });

        res.json(users);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
