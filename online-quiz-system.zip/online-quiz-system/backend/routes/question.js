const express = require("express");

const Question = require("../models/Question");
const auth = require("../middleware/auth");

const router = express.Router();


// GET QUESTIONS
router.get("/questions", auth, async (req, res) => {

    try {

        if (req.user.role !== "admin") {
            return res.status(403).json({
                message: "Admin access required"
            });
        }

        const questions = await Question.find();

        res.json(questions);

    } catch (error) {

        res.status(500).json({
            message: error.message
        });
    }
});


// ADD QUESTION
router.post("/question", auth, async (req, res) => {

    try {

        if (req.user.role !== "admin") {
            return res.status(403).json({
                message: "Admin access required"
            });
        }

        const question = new Question({
            categoryId: req.body.categoryId,
            question: req.body.question,
            options: req.body.options,
            correctAnswer: req.body.correctAnswer
        });

        await question.save();

        res.json({
            message: "Question added",
            question
        });

    } catch (error) {

        res.status(500).json({
            message: error.message
        });
    }
});


// UPDATE QUESTION
router.put("/question/:id", auth, async (req, res) => {

    if (req.user.role !== "admin") {
        return res.status(403).json({
            message: "Admin access required"
        });
    }

    const question = await Question.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true }
    );

    res.json(question);
});


// DELETE QUESTION
router.delete("/question/:id", auth, async (req, res) => {

    if (req.user.role !== "admin") {
        return res.status(403).json({
            message: "Admin access required"
        });
    }

    await Question.findByIdAndDelete(req.params.id);

    res.json({
        message: "Question deleted"
    });
});


module.exports = router;