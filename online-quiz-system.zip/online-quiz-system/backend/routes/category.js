const express = require("express");
const Category = require("../models/Category");
const auth = require("../middleware/auth");

const router = express.Router();


// GET CATEGORIES
router.get("/categories", async (req, res) => {

    const categories = await Category.find();

    res.json(categories);
});


// ADD CATEGORY
router.post("/category", auth, async (req, res) => {

    try {

        if (req.user.role !== "admin") {
            return res.status(403).json({
                message: "Admin access required"
            });
        }

        const category = new Category({
            name: req.body.name,
            description: req.body.description
        });

        await category.save();

        res.json({
            message: "Category added",
            category
        });

    } catch (error) {

        res.status(500).json({
            message: error.message
        });
    }
});


// UPDATE CATEGORY
router.put("/category/:id", auth, async (req, res) => {

    if (req.user.role !== "admin") {
        return res.status(403).json({
            message: "Admin access required"
        });
    }

    const category = await Category.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true }
    );

    res.json(category);
});


// DELETE CATEGORY
router.delete("/category/:id", auth, async (req, res) => {

    if (req.user.role !== "admin") {
        return res.status(403).json({
            message: "Admin access required"
        });
    }

    await Category.findByIdAndDelete(req.params.id);

    res.json({
        message: "Category deleted"
    });
});


module.exports = router;