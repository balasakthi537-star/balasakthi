const express = require("express");

const Question = require("../models/Question");
const Result = require("../models/Result");
const auth = require("../middleware/auth");

const router = express.Router();


// START QUIZ
router.post("/quiz/start", auth, async (req, res) => {

    try {

        const questions = await Question.find({
            categoryId: req.body.categoryId
        }).select("-correctAnswer");

        res.json({
            questions
        });

    } catch (error) {

        res.status(500).json({
            message: error.message
        });
    }
});


// SUBMIT QUIZ
router.post("/quiz/submit", auth, async (req, res) => {

    try {

        const {
            categoryId,
            answers
        } = req.body;

        let score = 0;

        for (const answer of answers) {

            const question = await Question.findById(
                answer.questionId
            );

            if (
                question &&
                question.correctAnswer === answer.answer
            ) {
                score++;
            }
        }

        const totalQuestions = answers.length;

        const percentage =
            totalQuestions === 0
                ? 0
                : Math.round(
                    (score / totalQuestions) * 100
                );

        const result = new Result({
            userId: req.user.id,
            categoryId,
            score,
            totalQuestions,
            percentage
        });

        await result.save();

        res.json({
            message: "Quiz submitted",
            score,
            totalQuestions,
            percentage,
            resultId: result._id
        });

    } catch (error) {

        res.status(500).json({
            message: error.message
        });
    }
});


// RESULTS
router.get("/results", auth, async (req, res) => {

    try {

        const results = await Result.find({
            userId: req.user.id
        })
        .populate("categoryId", "name")
        .sort({ date: -1 });

        res.json(results);

    } catch (error) {

        res.status(500).json({
            message: error.message
        });
    }
});


// LEADERBOARD
router.get("/leaderboard", async (req, res) => {

    try {

        const leaderboard = await Result.aggregate([
            {
                $group: {
                    _id: "$userId",
                    averageScore: { $avg: "$percentage" },
                    quizzesTaken: { $sum: 1 }
                }
            },
            { $sort: { averageScore: -1 } },
            { $limit: 10 },
            {
                $lookup: {
                    from: "users",
                    localField: "_id",
                    foreignField: "_id",
                    as: "user"
                }
            },
            {
                $unwind: {
                    path: "$user",
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $project: {
                    _id: 0,
                    userId: "$_id",
                    userName: { $ifNull: ["$user.name", "Unknown User"] },
                    averageScore: 1,
                    quizzesTaken: 1
                }
            }
        ]);

        res.json(leaderboard);

    } catch (error) {

        res.status(500).json({
            message: error.message
        });
    }
});


module.exports = router;