const API_BASE = "/api";
const token = localStorage.getItem("token");
const profile = document.getElementById("profile");

if (!token) {
    window.location.href = "index.html";
} else {
    loadProfile();
}

async function loadProfile() {
    try {
        const response = await fetch(`${API_BASE}/profile`, {
            headers: { Authorization: `Bearer ${token}` }
        });
        const data = await response.json();

        if (!response.ok) throw new Error(data.message || data.msg || "Failed to load profile");

        profile.innerHTML = `
            <div class="card">
                <h2>${escapeHtml(data.name)}</h2>
                <p><strong>Email:</strong> ${escapeHtml(data.email)}</p>
                <p><strong>Role:</strong> ${escapeHtml(data.role)}</p>
            </div>
        `;
    } catch (error) {
        profile.innerHTML = `<p class="error">${escapeHtml(error.message)}</p>`;
    }
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
