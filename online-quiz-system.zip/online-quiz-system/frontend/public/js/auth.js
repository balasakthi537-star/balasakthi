const API_BASE = "/api";

const loginForm = document.getElementById("loginForm");

if (loginForm) {
    loginForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const message = document.getElementById("message");
        message.textContent = "Logging in...";

        try {
            const response = await fetch(`${API_BASE}/login`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    email: document.getElementById("email").value.trim(),
                    password: document.getElementById("password").value
                })
            });

            const data = await response.json();

            if (!response.ok) {
                message.textContent = data.message || "Login failed";
                return;
            }

            localStorage.setItem("token", data.token);
            localStorage.setItem("user", JSON.stringify(data.user));
            window.location.href = data.user.role === "admin" ? "admin-dashboard.html" : "dashboard.html";
        } catch (error) {
            message.textContent = "Cannot connect to server. Start the backend first.";
            console.error(error);
        }
    });
}

const registerForm = document.getElementById("registerForm");

if (registerForm) {
    registerForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const message = document.getElementById("message");
        message.textContent = "Registering...";

        try {
            const response = await fetch(`${API_BASE}/register`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    name: document.getElementById("name").value.trim(),
                    email: document.getElementById("email").value.trim(),
                    password: document.getElementById("password").value
                })
            });

            const data = await response.json();
            message.textContent = data.message || "Registration failed";

            if (response.ok) {
                setTimeout(() => {
                    window.location.href = "index.html";
                }, 800);
            }
        } catch (error) {
            message.textContent = "Cannot connect to server. Start the backend first.";
            console.error(error);
        }
    });
}
