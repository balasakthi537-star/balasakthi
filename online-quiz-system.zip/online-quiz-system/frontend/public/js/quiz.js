const API_BASE = "/api";
const token = localStorage.getItem("token");
const categoryId = localStorage.getItem("categoryId");
let questions = [];

if (!token || !categoryId) {
    window.location.href = "dashboard.html";
} else {
    loadQuiz();
}

async function loadQuiz() {
    const container = document.getElementById("questions");

    try {
        const response = await fetch(`${API_BASE}/quiz/start`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            },
            body: JSON.stringify({ categoryId })
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.message || "Failed to load quiz");

        questions = data.questions || [];

        if (!questions.length) {
            container.innerHTML = "<p>No questions are available for this category.</p>";
            document.getElementById("submitQuiz").disabled = true;
            return;
        }

        displayQuestions();
    } catch (error) {
        container.innerHTML = `<p class="error">${escapeHtml(error.message)}</p>`;
        console.error(error);
    }
}

function displayQuestions() {
    const container = document.getElementById("questions");
    container.innerHTML = "";

    questions.forEach((question, index) => {
        const div = document.createElement("div");
        div.className = "question";

        const optionsHTML = question.options.map((option) => `
            <label>
                <input type="radio" name="q${index}" value="${escapeAttribute(option)}">
                ${escapeHtml(option)}
            </label>
        `).join("");

        div.innerHTML = `
            <h3>${index + 1}. ${escapeHtml(question.question)}</h3>
            ${optionsHTML}
        `;

        container.appendChild(div);
    });
}

document.getElementById("quizForm").addEventListener("submit", async (event) => {
    event.preventDefault();

    const answers = questions.map((question, index) => {
        const selected = document.querySelector(`input[name="q${index}"]:checked`);
        return {
            questionId: question._id,
            answer: selected ? selected.value : ""
        };
    });

    try {
        const response = await fetch(`${API_BASE}/quiz/submit`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            },
            body: JSON.stringify({ categoryId, answers })
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.message || "Quiz submission failed");

        localStorage.setItem("quizResult", JSON.stringify(data));
        window.location.href = "result.html";
    } catch (error) {
        alert(error.message);
        console.error(error);
    }
});

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function escapeAttribute(value) {
    return escapeHtml(value).replaceAll("`", "&#096;");
}
