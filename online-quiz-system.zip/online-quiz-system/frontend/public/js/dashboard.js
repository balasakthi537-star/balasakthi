const API_BASE = "/api";
const token = localStorage.getItem("token");

if (!token) {
    window.location.href = "index.html";
}

async function loadCategories() {
    const container = document.getElementById("categories");

    try {
        const response = await fetch(`${API_BASE}/categories`);
        const data = await response.json();

        if (!response.ok) throw new Error(data.message || "Failed to load categories");

        container.innerHTML = "";

        if (!data.length) {
            container.innerHTML = "<p>No quiz categories available yet.</p>";
            return;
        }

        data.forEach((category) => {
            const card = document.createElement("div");
            card.className = "card";
            card.innerHTML = `
                <h2>${escapeHtml(category.name)}</h2>
                <p>${escapeHtml(category.description || "")}</p>
                <button onclick="startQuiz('${category._id}')">Start Quiz</button>
            `;
            container.appendChild(card);
        });
    } catch (error) {
        container.innerHTML = `<p class="error">${escapeHtml(error.message)}</p>`;
        console.error(error);
    }
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function startQuiz(categoryId) {
    localStorage.setItem("categoryId", categoryId);
    window.location.href = "quiz.html";
}

function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("categoryId");
    localStorage.removeItem("quizResult");
    window.location.href = "index.html";
}

loadCategories();
