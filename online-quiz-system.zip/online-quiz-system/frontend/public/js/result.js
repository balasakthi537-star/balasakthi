const result = JSON.parse(localStorage.getItem("quizResult") || "null");
const container = document.getElementById("result");

if (!result) {
    container.innerHTML = `<p>No quiz result found.</p>`;
} else {
    container.innerHTML = `
        <h2>Score: ${result.score} / ${result.totalQuestions}</h2>
        <h2>Percentage: ${result.percentage}%</h2>
        <p>Quiz submitted successfully!</p>
    `;
}
