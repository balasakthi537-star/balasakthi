const API_BASE = "/api";
const token = localStorage.getItem("token");
const storedUser = JSON.parse(localStorage.getItem("user") || "null");

if (!token || storedUser?.role !== "admin") {
    window.location.href = "admin-login.html";
}

const headers = () => ({
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`
});

let categories = [];
let questions = [];

function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.href = "admin-login.html";
}

function showMessage(id, text, ok = false) {
    const el = document.getElementById(id);
    el.textContent = text;
    el.className = `message ${ok ? "success" : "error"}`;
    setTimeout(() => { el.textContent = ""; }, 3000);
}

async function request(url, options = {}) {
    const response = await fetch(`${API_BASE}${url}`, {
        ...options,
        headers: { ...headers(), ...(options.headers || {}) }
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || "Request failed");
    return data;
}

async function loadStats() {
    const data = await request("/admin/stats");
    document.getElementById("statUsers").textContent = data.users;
    document.getElementById("statCategories").textContent = data.categories;
    document.getElementById("statQuestions").textContent = data.questions;
    document.getElementById("statResults").textContent = data.results;
}

async function loadCategories() {
    categories = await request("/categories");
    const select = document.getElementById("questionCategory");
    select.innerHTML = '<option value="">Select category</option>' + categories.map(c =>
        `<option value="${c._id}">${escapeHtml(c.name)}</option>`
    ).join("");

    const table = document.getElementById("categoryTable");
    table.innerHTML = categories.length ? categories.map(c => `
        <tr>
            <td>${escapeHtml(c.name)}</td>
            <td>${escapeHtml(c.description || "")}</td>
            <td>
                <button class="small" onclick="editCategory('${c._id}')">Edit</button>
                <button class="small danger" onclick="deleteCategory('${c._id}')">Delete</button>
            </td>
        </tr>`).join("") : '<tr><td colspan="3">No categories yet.</td></tr>';
}

async function loadQuestions() {
    questions = await request("/questions");
    const table = document.getElementById("questionTable");
    table.innerHTML = questions.length ? questions.map(q => {
        const category = categories.find(c => c._id === q.categoryId);
        return `<tr>
            <td>${escapeHtml(category?.name || "Unknown")}</td>
            <td>${escapeHtml(q.question)}</td>
            <td>${q.options.map((o, i) => `${i + 1}. ${escapeHtml(o)}`).join("<br>")}</td>
            <td>${escapeHtml(q.correctAnswer)}</td>
            <td>
                <button class="small" onclick="editQuestion('${q._id}')">Edit</button>
                <button class="small danger" onclick="deleteQuestion('${q._id}')">Delete</button>
            </td>
        </tr>`;
    }).join("") : '<tr><td colspan="5">No questions yet.</td></tr>';
}

async function loadResults() {
    const results = await request("/admin/results");
    const table = document.getElementById("resultTable");
    table.innerHTML = results.length ? results.map(r => `
        <tr>
            <td>${escapeHtml(r.userId?.name || "Unknown")}</td>
            <td>${escapeHtml(r.userId?.email || "")}</td>
            <td>${escapeHtml(r.categoryId?.name || "Unknown")}</td>
            <td>${r.score}/${r.totalQuestions}</td>
            <td>${r.percentage}%</td>
            <td>${new Date(r.date).toLocaleString()}</td>
            <td><button class="small danger" onclick="deleteResult('${r._id}')">Delete</button></td>
        </tr>`).join("") : '<tr><td colspan="7">No quiz results yet.</td></tr>';
}

async function loadUsers() {
    const users = await request("/admin/users");
    const table = document.getElementById("userTable");
    table.innerHTML = users.length ? users.map(u => `
        <tr><td>${escapeHtml(u.name)}</td><td>${escapeHtml(u.email)}</td><td>${escapeHtml(u.role)}</td></tr>
    `).join("") : '<tr><td colspan="3">No users yet.</td></tr>';
}

function editCategory(id) {
    const c = categories.find(x => x._id === id);
    if (!c) return;
    document.getElementById("categoryId").value = c._id;
    document.getElementById("categoryName").value = c.name;
    document.getElementById("categoryDescription").value = c.description || "";
    document.getElementById("categoryFormTitle").textContent = "Edit Category";
    document.getElementById("cancelCategory").hidden = false;
    window.scrollTo({ top: 0, behavior: "smooth" });
}

async function deleteCategory(id) {
    if (!confirm("Delete this category? Questions using it may also become unusable.")) return;
    try {
        await request(`/category/${id}`, { method: "DELETE" });
        await refresh();
    } catch (error) {
        showMessage("categoryMessage", error.message);
    }
}

function resetCategoryForm() {
    document.getElementById("categoryForm").reset();
    document.getElementById("categoryId").value = "";
    document.getElementById("categoryFormTitle").textContent = "Add Category";
    document.getElementById("cancelCategory").hidden = true;
}

document.getElementById("categoryForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const id = document.getElementById("categoryId").value;
    const body = {
        name: document.getElementById("categoryName").value.trim(),
        description: document.getElementById("categoryDescription").value.trim()
    };
    try {
        await request(id ? `/category/${id}` : "/category", {
            method: id ? "PUT" : "POST",
            body: JSON.stringify(body)
        });
        resetCategoryForm();
        showMessage("categoryMessage", id ? "Category updated" : "Category added", true);
        await refresh();
    } catch (error) {
        showMessage("categoryMessage", error.message);
    }
});

document.getElementById("cancelCategory").addEventListener("click", resetCategoryForm);

function editQuestion(id) {
    const q = questions.find(x => x._id === id);
    if (!q) return;
    document.getElementById("questionId").value = q._id;
    document.getElementById("questionCategory").value = q.categoryId;
    document.getElementById("questionText").value = q.question;
    q.options.forEach((o, i) => document.getElementById(`option${i + 1}`).value = o);
    const answerIndex = q.options.indexOf(q.correctAnswer);
    document.getElementById("correctAnswer").value = answerIndex >= 0 ? String(answerIndex) : "";
    document.getElementById("questionFormTitle").textContent = "Edit Question";
    document.getElementById("cancelQuestion").hidden = false;
}

async function deleteQuestion(id) {
    if (!confirm("Delete this question?")) return;
    try {
        await request(`/question/${id}`, { method: "DELETE" });
        await refresh();
    } catch (error) {
        showMessage("questionMessage", error.message);
    }
}

function resetQuestionForm() {
    document.getElementById("questionForm").reset();
    document.getElementById("questionId").value = "";
    document.getElementById("questionFormTitle").textContent = "Add Question";
    document.getElementById("cancelQuestion").hidden = true;
}

document.getElementById("questionForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const id = document.getElementById("questionId").value;
    const options = [1,2,3,4].map(i => document.getElementById(`option${i}`).value.trim());
    const answerIndex = Number(document.getElementById("correctAnswer").value);
    const body = {
        categoryId: document.getElementById("questionCategory").value,
        question: document.getElementById("questionText").value.trim(),
        options,
        correctAnswer: options[answerIndex]
    };

    try {
        await request(id ? `/question/${id}` : "/question", {
            method: id ? "PUT" : "POST",
            body: JSON.stringify(body)
        });
        resetQuestionForm();
        showMessage("questionMessage", id ? "Question updated" : "Question added", true);
        await refresh();
    } catch (error) {
        showMessage("questionMessage", error.message);
    }
});

document.getElementById("cancelQuestion").addEventListener("click", resetQuestionForm);

async function deleteResult(id) {
    if (!confirm("Delete this quiz result?")) return;
    try {
        await request(`/admin/results/${id}`, { method: "DELETE" });
        await refresh();
    } catch (error) {
        document.getElementById("resultMessage").textContent = error.message;
    }
}

function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>'"]/g, char => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
    }[char]));
}

async function refresh() {
    try {
        await loadCategories();
        await loadQuestions();
        await Promise.all([loadStats(), loadResults(), loadUsers()]);
    } catch (error) {
        if (error.message === "Invalid token" || error.message === "Access denied") {
            logout();
            return;
        }
        console.error(error);
    }
}

refresh();
