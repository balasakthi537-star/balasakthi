const API_BASE = "/api";
const tableBody = document.getElementById("leaderboardBody");

async function loadLeaderboard() {
    try {
        const response = await fetch(`${API_BASE}/leaderboard`);
        const data = await response.json();

        if (!response.ok) throw new Error(data.message || "Failed to load leaderboard");

        tableBody.innerHTML = "";

        if (!data.length) {
            tableBody.innerHTML = '<tr><td colspan="3">No quiz results yet.</td></tr>';
            return;
        }

        data.forEach((item, index) => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${escapeHtml(item.userName || "Unknown User")}</td>
                <td>${Number(item.averageScore || 0).toFixed(1)}%</td>
            `;
            tableBody.appendChild(row);
        });
    } catch (error) {
        tableBody.innerHTML = `<tr><td colspan="3">${escapeHtml(error.message)}</td></tr>`;
        console.error(error);
    }
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

loadLeaderboard();
