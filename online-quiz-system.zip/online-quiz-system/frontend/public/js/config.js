// All frontend API requests go through the same Express server.
const API_BASE = "/api";
