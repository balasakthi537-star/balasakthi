Name: N Balasakthi
Domain Opted: Web Development
Project Title: Full Stack Expense Tracker - Minor Project
Internship: ShikshaVertex

Technologies Used: Node.js, Express.js, MongoDB Atlas, Nodemon, dotenv, Cloudflare WARP for connection

How to Run This Project:
1. npm install (to get node_modules back)
2. Create a .env file and add MONGO_URI and PORT
3. Connect Cloudflare WARP (needed for my mobile hotspot)
4. npm run dev
5. Open http://localhost:5000

Output: See Screenshots folder