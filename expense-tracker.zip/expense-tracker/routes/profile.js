const express = require("express");

const User = require("../models/User");
const auth = require("../middleware/auth");

const router = express.Router();


// GET PROFILE
router.get("/", auth, async (req, res) => {

    try {

        const user = await User.findById(req.user.id)
            .select("-password");

        res.json(user);

    } catch (error) {

        res.status(500).json({
            message: "Could not get profile."
        });

    }

});


// UPDATE PROFILE
router.put("/", auth, async (req, res) => {

    try {

        const {
            name,
            email,
            phone
        } = req.body;

        const user = await User.findByIdAndUpdate(
            req.user.id,
            {
                name,
                email,
                phone
            },
            {
                new: true,
                runValidators: true
            }
        ).select("-password");

        res.json({
            message: "Profile updated successfully.",
            user
        });

    } catch (error) {

        res.status(500).json({
            message: "Could not update profile.",
            error: error.message
        });

    }

});


module.exports = router;