const express = require("express");

const Expense = require("../models/Expense");
const auth = require("../middleware/auth");

const router = express.Router();


// GET ALL EXPENSES
router.get("/", auth, async (req, res) => {

    try {

        const { search, category, date } = req.query;

        let filter = {
            userId: req.user.id
        };

        if (search) {
            filter.title = {
                $regex: search,
                $options: "i"
            };
        }

        if (category && category !== "All") {
            filter.category = category;
        }

        if (date) {

            const start = new Date(date);

            const end = new Date(date);
            end.setDate(end.getDate() + 1);

            filter.date = {
                $gte: start,
                $lt: end
            };
        }

        const expenses = await Expense.find(filter)
            .sort({ date: -1 });

        res.json(expenses);

    } catch (error) {

        res.status(500).json({
            message: "Could not get expenses.",
            error: error.message
        });

    }

});


// ADD EXPENSE
router.post("/", auth, async (req, res) => {

    try {

        const {
            title,
            amount,
            category,
            description,
            date
        } = req.body;

        if (!title || !amount || !category || !date) {
            return res.status(400).json({
                message: "Please fill all required fields."
            });
        }

        const expense = await Expense.create({
            userId: req.user.id,
            title,
            amount,
            category,
            description,
            date
        });

        res.status(201).json({
            message: "Expense added successfully.",
            expense
        });

    } catch (error) {

        res.status(500).json({
            message: "Could not add expense.",
            error: error.message
        });

    }

});


// UPDATE EXPENSE
router.put("/:id", auth, async (req, res) => {

    try {

        const expense = await Expense.findOneAndUpdate(
            {
                _id: req.params.id,
                userId: req.user.id
            },
            req.body,
            {
                new: true,
                runValidators: true
            }
        );

        if (!expense) {
            return res.status(404).json({
                message: "Expense not found."
            });
        }

        res.json({
            message: "Expense updated successfully.",
            expense
        });

    } catch (error) {

        res.status(500).json({
            message: "Could not update expense.",
            error: error.message
        });

    }

});


// DELETE EXPENSE
router.delete("/:id", auth, async (req, res) => {

    try {

        const expense = await Expense.findOneAndDelete({
            _id: req.params.id,
            userId: req.user.id
        });

        if (!expense) {
            return res.status(404).json({
                message: "Expense not found."
            });
        }

        res.json({
            message: "Expense deleted successfully."
        });

    } catch (error) {

        res.status(500).json({
            message: "Could not delete expense.",
            error: error.message
        });

    }

});


// TOTAL EXPENSE
router.get("/total", auth, async (req, res) => {

    try {

        const result = await Expense.aggregate([
            {
                $match: {
                    userId: new (require("mongoose").Types.ObjectId)(
                        req.user.id
                    )
                }
            },
            {
                $group: {
                    _id: null,
                    total: {
                        $sum: "$amount"
                    }
                }
            }
        ]);

        const total = result.length > 0
            ? result[0].total
            : 0;

        res.json({
            total
        });

    } catch (error) {

        res.status(500).json({
            message: "Could not calculate total.",
            error: error.message
        });

    }

});


// MONTHLY EXPENSE
router.get("/monthly", auth, async (req, res) => {

    try {

        const mongoose = require("mongoose");

        const start = new Date();

        start.setDate(1);
        start.setHours(0, 0, 0, 0);

        const end = new Date();

        end.setMonth(end.getMonth() + 1);
        end.setDate(1);
        end.setHours(0, 0, 0, 0);

        const result = await Expense.aggregate([
            {
                $match: {
                    userId: new mongoose.Types.ObjectId(req.user.id),

                    date: {
                        $gte: start,
                        $lt: end
                    }
                }
            },
            {
                $group: {
                    _id: null,
                    total: {
                        $sum: "$amount"
                    }
                }
            }
        ]);

        const total = result.length > 0
            ? result[0].total
            : 0;

        res.json({
            total
        });

    } catch (error) {

        res.status(500).json({
            message: "Could not calculate monthly expense.",
            error: error.message
        });

    }

});


// CATEGORY SUMMARY
router.get("/category", auth, async (req, res) => {

    try {

        const mongoose = require("mongoose");

        const result = await Expense.aggregate([
            {
                $match: {
                    userId: new mongoose.Types.ObjectId(req.user.id)
                }
            },
            {
                $group: {
                    _id: "$category",
                    total: {
                        $sum: "$amount"
                    }
                }
            },
            {
                $sort: {
                    total: -1
                }
            }
        ]);

        res.json(result);

    } catch (error) {

        res.status(500).json({
            message: "Could not get category summary.",
            error: error.message
        });

    }

});


module.exports = router;