const dns = require('dns');
dns.setServers(['8.8.8.8', '1.1.1.1', '8.8.4.4']);
const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const path = require("path");

dotenv.config();

const authRoutes = require("./routes/auth");
const expenseRoutes = require("./routes/expenses");
const profileRoutes = require("./routes/profile");

const app = express();


// Middleware
app.use(express.json());


// Frontend
app.use(express.static(path.join(__dirname, "public")));


// API Routes
app.use("/api/auth", authRoutes);
app.use("/api/expenses", expenseRoutes);
app.use("/api/profile", profileRoutes);


// Home page
app.get("/", (req, res) => {

    res.sendFile(
        path.join(__dirname, "public", "index.html")
    );

});


// MongoDB Connection
mongoose
    .connect('mongodb+srv://balasakthi537_db_user:bala_2004@cluster0.ykmrxce.mongodb.net/expense-tracker?retryWrites=true&w=majority&appName=cluster0')
    .then(() => {

        console.log("MongoDB connected successfully.");

        app.listen(process.env.PORT, () => {

            console.log(
                `Server running at http://localhost:${process.env.PORT}`
            );

        });

    })
    .catch((error) => {

        console.error(
            "MongoDB connection failed:",
            error.message
        );

    });