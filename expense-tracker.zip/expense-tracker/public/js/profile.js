const token = localStorage.getItem("token");


if (!token) {

    window.location.href =
        "index.html";

}


function headers() {

    return {
        "Content-Type": "application/json",

        "Authorization":
            `Bearer ${token}`
    };

}


// LOAD PROFILE

async function loadProfile() {

    try {

        const response =
            await fetch(
                "/api/profile",
                {
                    headers: headers()
                }
            );


        if (!response.ok) {

            window.location.href =
                "index.html";

            return;
        }


        const user =
            await response.json();


        document.getElementById(
            "name"
        ).value = user.name;


        document.getElementById(
            "email"
        ).value = user.email;


        document.getElementById(
            "phone"
        ).value = user.phone || "";

    } catch (error) {

        console.error(error);

    }

}


// UPDATE PROFILE

document.getElementById(
    "profileForm"
).addEventListener(
    "submit",
    async function(event) {

        event.preventDefault();


        const name =
            document.getElementById(
                "name"
            ).value;


        const email =
            document.getElementById(
                "email"
            ).value;


        const phone =
            document.getElementById(
                "phone"
            ).value;


        try {

            const response =
                await fetch(
                    "/api/profile",
                    {
                        method: "PUT",

                        headers: headers(),

                        body: JSON.stringify({
                            name,
                            email,
                            phone
                        })
                    }
                );


            const data =
                await response.json();


            document.getElementById(
                "message"
            ).textContent =
                data.message;


        } catch (error) {

            document.getElementById(
                "message"
            ).textContent =
                "Could not update profile.";

        }

    }
);


// LOGOUT

document.getElementById(
    "logoutBtn"
).addEventListener(
    "click",
    function() {

        localStorage.clear();

        window.location.href =
            "index.html";

    }
);


loadProfile();