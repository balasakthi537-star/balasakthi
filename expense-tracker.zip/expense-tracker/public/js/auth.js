// LOGIN

const loginForm = document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener("submit", async function (event) {

        event.preventDefault();

        const email =
            document.getElementById("email").value;

        const password =
            document.getElementById("password").value;

        const message =
            document.getElementById("message");

        try {

            const response = await fetch(
                "/api/auth/login",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        email,
                        password
                    })
                }
            );

            const data = await response.json();

            if (!response.ok) {

                message.textContent = data.message;

                return;
            }

            localStorage.setItem(
                "token",
                data.token
            );

            localStorage.setItem(
                "user",
                JSON.stringify(data.user)
            );

            window.location.href = "dashboard.html";

        } catch (error) {

            message.textContent =
                "Server error. Please try again.";

        }

    });

}


// REGISTER

const registerForm =
    document.getElementById("registerForm");

if (registerForm) {

    registerForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();

            const name =
                document.getElementById("name").value;

            const email =
                document.getElementById("email").value;

            const phone =
                document.getElementById("phone").value;

            const password =
                document.getElementById("password").value;

            const message =
                document.getElementById("message");

            try {

                const response = await fetch(
                    "/api/auth/register",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/json"
                        },

                        body: JSON.stringify({
                            name,
                            email,
                            phone,
                            password
                        })
                    }
                );

                const data = await response.json();

                if (!response.ok) {

                    message.textContent =
                        data.message;

                    return;
                }

                message.textContent =
                    "Registration successful!";

                setTimeout(() => {

                    window.location.href =
                        "index.html";

                }, 1000);

            } catch (error) {

                message.textContent =
                    "Server error.";

            }

        }
    );

}