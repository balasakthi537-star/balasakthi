const token = localStorage.getItem("token");

if (!token) {
    window.location.href = "index.html";
}


const user =
    JSON.parse(localStorage.getItem("user"));

document.getElementById("userName").textContent =
    user ? user.name : "User";


const expenseForm =
    document.getElementById("expenseForm");

const expenseList =
    document.getElementById("expenseList");

const search =
    document.getElementById("search");

const filterCategory =
    document.getElementById("filterCategory");

const filterDate =
    document.getElementById("filterDate");


// API HEADER

function headers() {

    return {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`
    };

}


// LOAD EXPENSES

async function loadExpenses() {

    let url = "/api/expenses?";

    const searchValue = search.value;

    const categoryValue =
        filterCategory.value;

    const dateValue =
        filterDate.value;


    if (searchValue) {

        url +=
            `search=${encodeURIComponent(searchValue)}&`;

    }

    if (categoryValue) {

        url +=
            `category=${encodeURIComponent(categoryValue)}&`;

    }

    if (dateValue) {

        url +=
            `date=${dateValue}`;

    }


    try {

        const response = await fetch(
            url,
            {
                headers: headers()
            }
        );

        if (response.status === 401) {

            logout();

            return;
        }

        const expenses =
            await response.json();

        displayExpenses(expenses);

        document.getElementById(
            "transactionCount"
        ).textContent = expenses.length;

    } catch (error) {

        console.error(error);

    }

}


// DISPLAY EXPENSES

function displayExpenses(expenses) {

    expenseList.innerHTML = "";


    if (expenses.length === 0) {

        expenseList.innerHTML =
            "<p>No expenses found.</p>";

        return;
    }


    expenses.forEach(expense => {

        const card =
            document.createElement("div");

        card.className = "expense-card";


        card.innerHTML = `

            <div>

                <h3>${escapeHTML(expense.title)}</h3>

                <p>
                    Category:
                    ${escapeHTML(expense.category)}
                </p>

                <p>
                    ${escapeHTML(expense.description || "")}
                </p>

                <small>
                    ${new Date(expense.date)
                        .toLocaleDateString()}
                </small>

            </div>

            <div>

                <strong>
                    ₹${Number(expense.amount).toFixed(2)}
                </strong>

                <br>

                <button
                    onclick="editExpense('${expense._id}')">
                    Edit
                </button>

                <button
                    onclick="deleteExpense('${expense._id}')">
                    Delete
                </button>

            </div>
        `;


        expenseList.appendChild(card);

    });

}


// ADD EXPENSE

expenseForm.addEventListener(
    "submit",
    async function(event) {

        event.preventDefault();


        const expense = {

            title:
                document.getElementById("title").value,

            amount:
                Number(
                    document.getElementById("amount").value
                ),

            category:
                document.getElementById("category").value,

            date:
                document.getElementById("date").value,

            description:
                document.getElementById("description").value
        };


        try {

            const response = await fetch(
                "/api/expenses",
                {
                    method: "POST",

                    headers: headers(),

                    body: JSON.stringify(expense)
                }
            );


            const data =
                await response.json();


            if (!response.ok) {

                alert(data.message);

                return;
            }


            alert("Expense added successfully!");

            expenseForm.reset();

            loadExpenses();

            loadStatistics();

        } catch (error) {

            alert("Could not add expense.");

        }

    }
);


// DELETE EXPENSE

async function deleteExpense(id) {

    const confirmDelete =
        confirm(
            "Are you sure you want to delete this expense?"
        );


    if (!confirmDelete) {
        return;
    }


    try {

        const response = await fetch(
            `/api/expenses/${id}`,
            {
                method: "DELETE",
                headers: headers()
            }
        );


        const data =
            await response.json();


        alert(data.message);


        loadExpenses();

        loadStatistics();

    } catch (error) {

        alert("Could not delete expense.");

    }

}


// EDIT EXPENSE

async function editExpense(id) {

    const title =
        prompt("Enter new title:");

    if (!title) {
        return;
    }


    const amount =
        prompt("Enter new amount:");

    if (!amount) {
        return;
    }


    try {

        const response = await fetch(
            `/api/expenses/${id}`,
            {
                method: "PUT",

                headers: headers(),

                body: JSON.stringify({
                    title,
                    amount: Number(amount)
                })
            }
        );


        const data =
            await response.json();


        alert(data.message);


        loadExpenses();

        loadStatistics();

    } catch (error) {

        alert("Could not update expense.");

    }

}


// STATISTICS

async function loadStatistics() {

    try {

        const totalResponse =
            await fetch(
                "/api/expenses/total",
                {
                    headers: headers()
                }
            );

        const totalData =
            await totalResponse.json();


        document.getElementById(
            "totalExpense"
        ).textContent =
            `₹${Number(totalData.total).toFixed(2)}`;


        const monthlyResponse =
            await fetch(
                "/api/expenses/monthly",
                {
                    headers: headers()
                }
            );

        const monthlyData =
            await monthlyResponse.json();


        document.getElementById(
            "monthlyExpense"
        ).textContent =
            `₹${Number(monthlyData.total).toFixed(2)}`;

    } catch (error) {

        console.error(error);

    }

}


// SEARCH

search.addEventListener(
    "input",
    loadExpenses
);


// CATEGORY FILTER

filterCategory.addEventListener(
    "change",
    loadExpenses
);


// DATE FILTER

filterDate.addEventListener(
    "change",
    loadExpenses
);


// LOGOUT

document.getElementById(
    "logoutBtn"
).addEventListener(
    "click",
    logout
);


function logout() {

    localStorage.removeItem("token");

    localStorage.removeItem("user");

    window.location.href =
        "index.html";
}


// BASIC HTML ESCAPE

function escapeHTML(value) {

    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");

}


// INITIAL LOAD

loadExpenses();

loadStatistics();